// 发布页 http://www.8kvod.com/
// 一级筛选 数字验证
muban.mxone5.二级.title = 'h1&&Text;.video-info-aux&&Text';
muban.mxone5.二级.desc = '.video-info-items:eq(5)&&Text;;;.video-info-actor:eq(1)&&Text;.video-info-actor:eq(0)&&Text';
var rule={
    title:'8K影视',
    模板:'mxone5',
    host:'http://www.8kvod.com',
    hostJs:'print(HOST);let html=request(HOST,{headers:{"User-Agent":PC_UA}});let src = jsp.pdfh(html,"ul&&li&&a&&href");print(src);HOST=src.replace("/index.php","")',
    // host:'http://www.xn--45q.top',
    homeUrl:'/index.php',
    url:'/t/fyclass-fypage/',
    class_name:'足球&篮球&网球&动作片&喜剧片&爱情片&科幻片&恐怖片&剧情片&战争片&惊悚片&犯罪片&冒险片&悬疑片&奇幻片&纪录片&动画片&其他片&国产剧&港台剧&日韩剧&欧美剧&海外剧&大陆综艺&港台综艺&国外综艺&歌曲MV&国产动漫&日本动漫&欧美动漫&其他动漫&早教&亲子&儿歌',
    class_url:'53&54&55&6&7&8&9&10&11&12&48&49&50&51&52&28&29&31&13&14&15&16&20&21&22&23&39&24&25&26&27&44&45&46',
    searchUrl:'/vse**/page/fypage/',
    图片来源:'@Referer=http://www.xn--45q.top',
}