package com.github.catvod.spider;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import com.github.catvod.crawler.SpiderDebug;
import com.github.catvod.spider.merge.hccx.p044B.C3658;
import com.github.catvod.spider.merge.hccx.p058P.C3675;
import com.github.catvod.spider.merge.hccx.p063U.C3682;
import com.github.catvod.spider.merge.hccx.p077e.C3700;
import com.github.catvod.spider.merge.hccx.p091l.C3716;
import com.github.catvod.spider.merge.hccx.p103r0.C3727;
import com.github.catvod.spider.merge.hccx.p116y0.C3745;
import com.github.catvod.spider.merge.p012M.C3631;
import com.github.catvod.spider.merge.p012M.C3633;
import com.github.catvod.spider.merge.p022W.C3636;
import com.github.catvod.spider.merge.p032c0.C3648;
import com.github.catvod.spider.merge.p133pm.p135b.RunnableC2243a;
import com.github.catvod.spider.merge.p133pm.p146n.C3776;
import java.lang.reflect.Field;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* loaded from: classes.dex */
public class Init {

    /* renamed from: short  reason: not valid java name */
    private static final short[] f6664short = {2181, 2186, 2176, 2198, 2187, 2189, 2176, 2250, 2181, 2196, 2196, 2250, 2213, 2183, 2192, 2189, 2194, 2189, 2192, 2205, 2224, 2188, 2198, 2177, 2181, 2176, 769, 791, 784, 784, 775, 780, 790, 803, 769, 790, 779, 788, 779, 790, 795, 822, 778, 784, 775, 771, 774, 3281, 3325, 3295, 3272, 3285, 3274, 3285, 3272, 3285, 3289, 3279, 1674, 1691, 1679, 1673, 1695, 1694, 2114, 2112, 2135, 2122, 2133, 2122, 2135, 2138, -30617, 21015, 18372, 31649, -28698, 18286, 29068, -30992, 22760, 27549, 23314, -2420, 1428, 1416, 1416, 1420, 1423, 1478, 1491, 1491, 1435, 1429, 1416, 1439, 1427, 1432, 1433, 1490, 1426, 1433, 1416, 1491, 1425, 1484, 1443, 1483, 1487, 1477, 1476, 1477, 1486, 1485, 1483, 1491, 1413, 1425, 1414, 1491, 1489, 1491, 1422, 1437, 1419, 1491, 1425, 1437, 1423, 1416, 1433, 1422, 1491, 1462, 1469, 1454, 1491, 1413, 1425, 1490, 1416, 1412, 1416, 2978, 2984, 2985};

    /* renamed from: c */
    private Application f73c;

    /* renamed from: b */
    private final Handler f72b = new Handler(Looper.getMainLooper());

    /* renamed from: a */
    private final ExecutorService f71a = Executors.newFixedThreadPool(5);

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class Loader {

        /* renamed from: a */
        static volatile Init f74a = new Init();

        private Loader() {
        }
    }

    public Init() {
        if (C3716.m8913() <= 0) {
            System.out.println(Float.decode(C3745.m8997("NhGOWPxQl")));
        }
    }

    public static Application context() {
        return get().f73c;
    }

    public static void execute(Runnable runnable) {
        get().f71a.execute(runnable);
        if (C3727.m8944() <= 0) {
            System.out.println(Float.valueOf(C3776.m9092("fE6jOFo6ULnCuvVVx")));
        }
    }

    public static Init get() {
        return Loader.f74a;
    }

    public static Activity getActivity() {
        Class<?> cls = Class.forName(C3633.m8655(f6664short, 0, 26, 2276));
        Object invoke = cls.getMethod(C3700.m8865(f6664short, 26, 21, 866), new Class[0]).invoke(null, new Object[0]);
        Field declaredField = cls.getDeclaredField(C3631.m8650(f6664short, 47, 11, 3260));
        declaredField.setAccessible(true);
        for (Object obj : ((Map) declaredField.get(invoke)).values()) {
            Class<?> cls2 = obj.getClass();
            Field declaredField2 = cls2.getDeclaredField(C3682.m8805(f6664short, 58, 6, 1786));
            declaredField2.setAccessible(true);
            if (!declaredField2.getBoolean(obj)) {
                Field declaredField3 = cls2.getDeclaredField(C3675.m8783(f6664short, 64, 8, 2083));
                declaredField3.setAccessible(true);
                Activity activity = (Activity) declaredField3.get(obj);
                SpiderDebug.log(activity.getComponentName().getClassName());
                return activity;
            }
        }
        return null;
    }

    public static void init(Context context) {
        SpiderDebug.log(C3648.m8699(f6664short, 72, 12, 2445));
        get().f73c = (Application) context;
        Notice notice = new Notice();
        String GetResult = Notice.GetResult(C3636.m8663(f6664short, 84, 59, 1532));
        notice.init(context, GetResult + C3658.m8734(f6664short, 143, 3, 2969));
    }

    public static void run(Runnable runnable) {
        get().f72b.post(runnable);
    }

    public static void run(Runnable runnable, int i) {
        get().f72b.postDelayed(runnable, i);
    }

    public static void show(String str) {
        get().f72b.post(new RunnableC2243a(str, 0));
    }
}