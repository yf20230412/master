package com.github.catvod.spider;

import android.content.Context;
import com.github.catvod.crawler.Spider;
import com.github.catvod.spider.merge.p029b.C1152r;
import com.github.catvod.spider.merge.p031c.C1175e;
import com.github.catvod.spider.merge.wIn;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* loaded from: classes.dex */
public class Ali extends Spider {

    /* renamed from: a */
    public static final Pattern f10a = Pattern.compile(wIn.m3332d("3005067A003B2E0B043A05252E04147A02382A5D027B490C195D2C7F487F68141E380532355D590F3F781A59587D5E"));

    public static Object[] proxy(Map<String, String> map) {
        String str = map.get(wIn.m3332d("330B0131"));
        if (str.equals(wIn.m3332d("340713"))) {
            return C1152r.m5692q().m5716J(map);
        }
        if (str.equals(wIn.m3332d("331D1A310F"))) {
            return C1152r.m5692q().m5683z();
        }
        return null;
    }

    public String detailContent(List<String> list) {
        String trim = list.get(0).trim();
        Matcher matcher = f10a.matcher(trim);
        if (matcher.find()) {
            String group = matcher.group(1);
            String group2 = matcher.groupCount() == 3 ? matcher.group(3) : "";
            C1152r.m5692q().m5713M(group);
            return C1175e.m5666i(C1152r.m5692q().m5723C(trim, group2));
        }
        return "";
    }

    public void init(Context context, String str) {
        C1152r.m5692q().m5714L(str);
    }

    public String playerContent(String str, String str2, List<String> list) {
        String[] split = str2.split(wIn.m3332d("1B59"));
        if (str.equals(wIn.m3332d("A2FCEEB3F4FC"))) {
            C1152r m5692q = C1152r.m5692q();
            m5692q.getClass();
            C1175e c1175e = new C1175e();
            c1175e.m5659p(m5692q.m5691r(split[0]));
            c1175e.m5669f();
            c1175e.m5660o(m5692q.m5684y(split));
            c1175e.m5672c(m5692q.m5690s());
            return c1175e.toString();
        }
        return C1152r.m5692q().m5718H(split, str);
    }
}